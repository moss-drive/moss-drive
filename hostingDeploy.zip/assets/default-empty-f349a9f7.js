const e="/img/stone/default-empty.png";export{e};
