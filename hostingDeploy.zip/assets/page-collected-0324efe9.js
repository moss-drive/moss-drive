import{_ as e,c,o}from"./index-cc2ac519.js";const t={};function n(r,l){return o(),c("div",null,"Collected")}const s=e(t,[["render",n]]);export{s as default};
